from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect('/')  # Redirect to home page after successful login
        else:
            messages.error(request, 'Invalid username or password.')
            return render(request, 'login.html')
    else:
        return render(request, 'login.html')


def register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']

        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request,'Username taken.')
                print('usernamexist')
                return render(request, 'register.html')  # Fixed redirect
            elif User.objects.filter(email=email).exists():
                messages.info(request, 'Email taken.')
                print('emailtaken')
                return render(request, 'register.html')  # Fixed redirect
            else:
                user = User.objects.create_user(
                    username=username,
                    first_name=first_name,
                    last_name=last_name,
                    email=email,
                    password=password1
                )
                user.save()
                messages.success(request, 'User created successfully.')
                print('user created')
                return render(request, 'login.html')  # Redirect to the login page after successful registration
        else:
            messages.error(request, 'Passwords do not match.')
            print('passworderror')
            return render(request, 'register.html')  # Fixed redirect
    else:
        return render(request, 'register.html')


def logout(request):
    auth.logout(request)
    messages.info(request, 'Logged out successfully.')
    return redirect('/')
