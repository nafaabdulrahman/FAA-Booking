from django.contrib import admin
from .models import pitchures
# Register your models here.
admin.site.register(pitchures)
#in browrser it will be added