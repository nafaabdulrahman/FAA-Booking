from django.shortcuts import render
from .models import pitchures

# Create your views here.
def index(request):
   pitchs=pitchures.objects.all
   return render(request,'index.html',{'pitchs':pitchs})
